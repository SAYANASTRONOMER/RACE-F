# HexGL-by-BKcore
This is a game created by BKcore, a French Developer. I have taken permission from him and done a whole lot of editing work, added sounds and even some graphics.
